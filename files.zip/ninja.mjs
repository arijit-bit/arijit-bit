#!/usr/bin/env node
// Shadow Ninja contribution-grid animation generator (no dependencies, Node 18+).
//
// Usage: node ninja.mjs <github-user> [outDir]
// Output: <outDir>/ninja-dark.svg and <outDir>/ninja-light.svg
//
// A shadow ninja dashes through your contribution grid and slices every
// green block (a day with contributions) in half. When the grid is clear the
// enemies respawn and the loop restarts.

import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const user = process.argv[2] || process.env.GITHUB_USER;
const outDir = process.argv[3] || "dist";
if (!user) {
  console.error("Usage: node ninja.mjs <github-user> [outDir]");
  process.exit(1);
}

// ---------- layout constants ----------
const CELL = 10;
const PITCH = 12;
const PAD_X = 16;
const PAD_Y = 16;

// ---------- palettes ----------
const PALETTES = {
  dark: {
    empty: "#161b22",
    levels: ["#0e4429", "#006d32", "#26a641", "#39d353"],
    body: "#06080c",
    scarf: "#79C0FF",
    eye: "#e6f4ff",
    blade: "#e6edf3",
    glow: "#79C0FF",
    slash: "#ffffff",
    slashGlow: "#79C0FF",
  },
  light: {
    empty: "#ebedf0",
    levels: ["#9be9a8", "#40c463", "#30a14e", "#216e39"],
    body: "#1b1f24",
    scarf: "#0969da",
    eye: "#ffffff",
    blade: "#57606a",
    glow: "#57606a",
    slash: "#1b1f24",
    slashGlow: "#0969da",
  },
};

// ---------- fetch contribution calendar ----------
async function fetchCells(login) {
  const url = `https://github.com/users/${login}/contributions`;
  let lastErr;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { "user-agent": "ninja-profile-generator" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const html = await res.text();
      const tags = html.match(/<td[^>]*ContributionCalendar-day[^>]*>/g) || [];
      const cells = [];
      for (const tag of tags) {
        const date = /data-date="([^"]+)"/.exec(tag)?.[1];
        const level = /data-level="(\d)"/.exec(tag)?.[1];
        if (date && level !== undefined) cells.push({ date, level: Number(level) });
      }
      if (!cells.length) throw new Error("no contribution cells found");
      return cells;
    } catch (err) {
      lastErr = err;
      await new Promise((r) => setTimeout(r, 1500 * attempt));
    }
  }
  throw new Error(`Could not fetch contributions for ${login}: ${lastErr}`);
}

function layoutCells(raw) {
  const DAY = 86400000;
  const cells = raw
    .map((c) => ({ ...c, t: Date.parse(`${c.date}T00:00:00Z`) }))
    .sort((a, b) => a.t - b.t);
  const firstSunday = cells[0].t - new Date(cells[0].t).getUTCDay() * DAY;
  for (const c of cells) {
    c.row = new Date(c.t).getUTCDay();
    c.col = Math.floor((c.t - firstSunday) / (7 * DAY));
  }
  const weeks = Math.max(...cells.map((c) => c.col)) + 1;
  return { cells, weeks };
}

// ---------- SVG builder ----------
function build({ cells, weeks }, theme) {
  const p = PALETTES[theme];
  const W = weeks * PITCH - (PITCH - CELL) + 2 * PAD_X;
  const H = 7 * PITCH - (PITCH - CELL) + 2 * PAD_Y;
  const cx = (c) => PAD_X + c.col * PITCH;
  const cy = (c) => PAD_Y + c.row * PITCH;

  // zig-zag path: even columns top->bottom, odd columns bottom->top
  const enemies = cells
    .filter((c) => c.level > 0)
    .sort((a, b) => a.col - b.col || (a.col % 2 === 0 ? a.row - b.row : b.row - a.row));

  // ----- raw timeline (seconds before scaling) -----
  const startX = -28;
  const exitX = W + 28;
  const y0 = enemies.length ? cy(enemies[0]) + CELL / 2 : H / 2;
  const lead = 0.3;
  let t = lead;
  let pos = { x: startX, y: y0 };
  const steps = [];
  for (const e of enemies) {
    const x = cx(e) + CELL / 2;
    const y = cy(e) + CELL / 2;
    const dist = Math.hypot(x - pos.x, y - pos.y) / PITCH;
    const arrive = t + 0.05 + 0.01 * dist;
    const hit = arrive + 0.01;
    const leave = hit + 0.03;
    steps.push({ e, x, y, arrive, hit, leave });
    pos = { x, y };
    t = leave;
  }
  const exitDash = 0.6;
  const rawExit = t + exitDash;

  // scale so the run lasts between ~9 and ~22 seconds
  const scale = rawExit < 9 ? Math.min(9 / rawExit, 3) : rawExit > 22 ? 22 / rawExit : 1;
  for (const s of steps) {
    s.arrive *= scale; s.hit *= scale; s.leave *= scale;
  }
  const lead_s = lead * scale;
  const exitAt = rawExit * scale;
  const respawnStart = exitAt + 0.5;
  const respawnSpan = 0.5;
  const respawnFade = 0.35;
  const T = respawnStart + respawnSpan + respawnFade + 0.9;
  const pct = (sec) => ((sec / T) * 100).toFixed(4);

  // ----- ninja keyframes -----
  const pt = (x, y) => `transform:translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`;
  const ease = "animation-timing-function:cubic-bezier(.35,0,.15,1)";
  const nk = [`0%{${pt(startX, y0)}}`, `${pct(lead_s)}%{${pt(startX, y0)};${ease}}`];
  for (const s of steps) {
    nk.push(`${pct(s.arrive)}%{${pt(s.x, s.y)}}`);
    nk.push(`${pct(s.leave)}%{${pt(s.x, s.y)};${ease}}`);
  }
  const exitY = steps.length ? steps[steps.length - 1].y : y0;
  nk.push(`${pct(exitAt)}%{${pt(exitX, exitY)}}`);
  nk.push(`${pct(exitAt + 0.0005)}%,100%{${pt(startX, y0)}}`);

  // ----- slash flash keyframes (attached to the ninja) -----
  const sk = ["0%{opacity:0}"];
  steps.forEach((s, i) => {
    const next = steps[i + 1];
    const fade = Math.min(0.12, next ? (next.hit - s.hit) * 0.8 : 0.12);
    sk.push(`${pct(s.hit - 0.006 * scale)}%{opacity:0}`);
    sk.push(`${pct(s.hit)}%{opacity:1}`);
    sk.push(`${pct(s.hit + fade)}%{opacity:0}`);
  });
  sk.push("100%{opacity:0}");

  // ----- enemy shapes + keyframes -----
  let enemyShapes = "";
  let enemyKF = "";
  steps.forEach((s, i) => {
    const r = ((i * 9301 + 49297) % 233280) / 233280;
    const r2 = ((i * 4421 + 12345) % 233280) / 233280;
    const x = cx(s.e);
    const y = cy(s.e);
    const rs = respawnStart + (s.e.col / weeks) * respawnSpan;
    const tail = `${pct(rs)}%{opacity:0;transform:none}${pct(rs + respawnFade)}%,100%{opacity:1;transform:none}`;
    const head = `0%,${pct(s.hit)}%{opacity:1;transform:none}`;
    const gone = pct(s.hit + 0.45);
    const ax = -(3 + 2 * r).toFixed(1), ay = -(2 + 2 * r2).toFixed(1);
    const bx = (3 + 2 * r2).toFixed(1), by = (4 + 3 * r).toFixed(1);
    const ar = -(14 + 26 * r).toFixed(0), br = (14 + 26 * r2).toFixed(0);
    enemyKF += `@keyframes a${i}{${head}${gone}%{opacity:0;transform:translate(${ax}px,${ay}px) rotate(${ar}deg) scale(.5)}${tail}}`;
    enemyKF += `@keyframes b${i}{${head}${gone}%{opacity:0;transform:translate(${bx}px,${by}px) rotate(${br}deg) scale(.5)}${tail}}`;
    const L = `l${s.e.level}`;
    enemyShapes +=
      `<polygon class="h ${L}" style="animation-name:a${i}" points="${x},${y} ${x + CELL},${y} ${x},${y + CELL}"/>` +
      `<polygon class="h ${L}" style="animation-name:b${i}" points="${x + CELL},${y} ${x + CELL},${y + CELL} ${x},${y + CELL}"/>`;
  });

  // ----- empty base cells (one path) -----
  const base = cells.map((c) => `M${cx(c)} ${cy(c)}h${CELL}v${CELL}h-${CELL}z`).join("");

  const levelCss = p.levels
    .map((col, i) => `.l${i + 1}{fill:${col};stroke:${col};stroke-width:.5}`)
    .join("");

  const dur = `${T.toFixed(3)}s`;
  const css =
    `.b{fill:${p.empty}}` +
    levelCss +
    `.h{transform-box:fill-box;transform-origin:center;animation-duration:${dur};animation-iteration-count:infinite;animation-timing-function:ease-out}` +
    `.m{animation:ninja ${dur} infinite both}` +
    `.g1{animation-delay:.07s;opacity:.32}.g2{animation-delay:.14s;opacity:.16}` +
    `.s{opacity:0;animation:slash ${dur} infinite}` +
    `@keyframes ninja{${nk.join("")}}` +
    `@keyframes slash{${sk.join("")}}` +
    enemyKF +
    `@media (prefers-reduced-motion:reduce){.m{display:none}.h{animation:none}}`;

  const ninja =
    `<g id="n" fill="${p.body}">` +
    // scarf tails
    `<path d="M-2.2,-6.6 C-5,-7.8 -8,-6.8 -11.5,-9.2 C-9,-6.2 -6.5,-5 -2.2,-4.8Z" fill="${p.scarf}"/>` +
    `<path d="M-2.2,-5.4 C-5.5,-5.2 -8.5,-3.2 -11,-3.4 C-8.5,-1.8 -6,-2.4 -2.2,-3.8Z" fill="${p.scarf}" opacity=".8"/>` +
    // head, headband, eyes
    `<circle cx="0.4" cy="-5.6" r="3.2"/>` +
    `<path d="M-2.4,-7.2 L3.2,-7.2 L3.3,-6 L-2.5,-6Z" fill="${p.scarf}"/>` +
    `<rect x="0.8" y="-5.1" width="3" height="1.1" rx=".5" fill="${p.eye}"/>` +
    // torso
    `<path d="M-3,-2.6 L2.6,-2.6 L1.8,3.4 L-2.4,3.4Z"/>` +
    // limbs
    `<g stroke="${p.body}" stroke-width="2" stroke-linecap="round" fill="none">` +
    `<path d="M-1.4,3 L-5,7.6"/><path d="M1,3 L4.6,6.4"/>` +
    `<path d="M-2.2,-1.6 L-6,0.8"/><path d="M2,-1.6 L6,-3.4"/>` +
    `</g>` +
    // katana
    `<path d="M6,-3.2 L15,-9.4" stroke="${p.blade}" stroke-width=".9" stroke-linecap="round" fill="none"/>` +
    `<path d="M5.4,-5 L7,-1.8" stroke="${p.scarf}" stroke-width="1" stroke-linecap="round" fill="none"/>` +
    `</g>`;

  const slashPath = "M-11,8 Q0,-1 11,-8";
  const slash =
    `<g class="s">` +
    `<path d="${slashPath}" stroke="${p.slashGlow}" stroke-width="3.4" stroke-linecap="round" fill="none" opacity=".4"/>` +
    `<path d="${slashPath}" stroke="${p.slash}" stroke-width="1.3" stroke-linecap="round" fill="none"/>` +
    `</g>`;

  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="A shadow ninja slicing through the GitHub contribution grid">` +
    `<title>Shadow ninja slicing through the contribution grid</title>` +
    `<style>${css}</style>` +
    `<defs>` +
    `<filter id="glow" x="-60%" y="-60%" width="220%" height="220%">` +
    `<feGaussianBlur in="SourceAlpha" stdDeviation="1.4" result="b"/>` +
    `<feFlood flood-color="${p.glow}" flood-opacity=".85"/>` +
    `<feComposite in2="b" operator="in" result="g"/>` +
    `<feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge>` +
    `</filter>` +
    ninja +
    `</defs>` +
    `<path class="b" d="${base}"/>` +
    enemyShapes +
    `<use class="m g2" href="#n"/>` +
    `<use class="m g1" href="#n"/>` +
    `<g class="m"><use href="#n" filter="url(#glow)"/>${slash}</g>` +
    `</svg>`;

  return { svg, T, enemies: enemies.length };
}

// ---------- main ----------
const data = layoutCells(await fetchCells(user));
mkdirSync(outDir, { recursive: true });
for (const theme of ["dark", "light"]) {
  const { svg, T, enemies } = build(data, theme);
  const file = join(outDir, `ninja-${theme}.svg`);
  writeFileSync(file, svg);
  console.log(`${file}: ${enemies} enemies, ${T.toFixed(1)}s loop, ${(svg.length / 1024).toFixed(0)} KB`);
}
